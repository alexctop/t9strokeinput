﻿Windows 改良版小小輸入法 2014年3月版

近日發覺很多人都 不能 在 Windows 8.1 系統 成功裝上 有 關連詞語的 簡易速成輸入法。

現在特別為此 介紹一個 非常好用的 自訂 Windows 中文輸入法
經我自己 修改碼表的 thhui18改良版小小輸入法(yong).

這個輸入法源出於中國的周永先生，再由台灣的Terry泰瑞兄修改過，最後我又再加上自己的一些輸入法碼表而成的。

安裝及設置：-

中文輸入 可以揀 簡易、倉頡、大新倉頡、廣東拼音、漢語拼音
其他國文字 可以揀 韓文拼音、日文拼音、英文

這個輸入法是可以安裝在:-
-WinXP
-Vista
-Win7(32/64)
-Win8(32/64)
-Win8.1(32/64)
的系統當中。

開啟／關閉輸入法主視窗
CTL-SPACE
(現在碼表default 已改為 CTL-`) 
「註：這個` 是左上角1字的左方鍵」

設置其實是可打繁打簡的，
中文輸入法預設是打繁體字。
只有漢語拼音(無調號)是預設為簡體字的，要按Ctl-Alt-S轉為繁體。

平時如要改成打簡體字
按Ctl-Alt-S 可以toggle打簡打繁

中英切換是
按Left-SHIFT一下 可以toggle打英打中

預設輸入法 是 香港簡易或速成 (候選字按WinXp傳統排列，有關連字候選字提供)
Ctl+Shift+1 倉頡
Ctl+Shift+2 簡易（候選字按WinXP香港速成排列）
Ctl+Shift+3 韓文
Ctl+Shift+4 廣東拼音
Ctl+Shift+5 漢語拼音（無調號）
Ctl+Shift+7 大新倉頡
Ctl+Shift+8 日文
Ctl+Shift+9 英文

Windows 版的小小輸入法雖然可以不用安裝，
直接執行主程式（yong.exe）就可以輕鬆輸入中文，

但是「免安裝版」（外掛版）仍然有些限制，
比如：組字窗格可能不會跟隨插入點位置，
或是「預編輯模式」不能實現、不能在 Windows 8 Metro APP 下使用…等，
因此使用「安裝版」（內置版）對某些人而言，可能是非常需要的。

所以，我最近測試了一下小小輸入法的內置方式和效果，
並將 改良版小小輸入法加上了安裝版所需的檔案。
習慣用免安裝版的網友可以繼續使用外掛版，
而如果想試試安裝版的人，可以依下列步驟設置。

一、下載 thhui18改良版小小輸入法，並解壓縮：
　　「thhui18改良版小小輸入法」
     thhui18_yong.rar 
     下載網址是：
     <a href="https://drive.google.com/file/d/0B4GQBWovm6BYOTJaQnJ1a21mWmM/edit?usp=sharing">https://drive.google.com/file/d/0B4GQBWovm6BYOTJaQnJ1a21mWmM/edit?usp=sharing</a>
    
　　解壓縮後，請注意「yong.exe」在磁碟裡的路徑不要包括中文和空白字元，
　　比如：「C:\小小輸入法\yong.exe」、「C:\thhui18 Yong\yong.exe」這樣的路徑是不行的！
　　像是「C:\thhui18_Yong\yong.exe」這樣的路徑才是 OK 的。

二、修改「yong.ini」（此檔案存放在「.yong」資料夾內），
　　需要修改的地方只有一行，找到「trigger=CTRL_SPACE」，
　　修改成「trigger=CTRL_`」（ESC 下方的按鍵）即可。（已修改了！）　

　　這項修改目的是方便 Windows XP/Vista/7 的使用者，
　　使用 Ctrl + Space 就能順利切換到內置版的小小輸入法。

　　如果是行列使用者，請再將「default=2」修改為「default=13」；
　　如果是大易使用者，請再將「default=2」修改為「default=12」；
　　如果是無蝦米使用者，請再將「default=2」修改為「default=10」；

三、內置技術有 2 種：IMM 和 TSF，
　　Windows XP/Vista/7 使用者，建議使用 IMM（Input Method Manager）；
　　Windows 8 使用者，建議使用 TSF（Text Service Framework），但是它的限制比較多！

（一）IMM：
　　執行「imm」資料夾裡的「install.bat」。
　　如果您的 Windows 是 64 位元版，
　　請先執行「install64.bat」，再執行「install.bat」。
　　以後，如果要更新內置模版，
　　請先執行「uninstall.bat」及「uninstall64.bat」，
　　然後再執行一次「install64.bat」及「install.bat」。

（二）TSF：
　　必須先將「thhui18_Yong」資料夾，複製到「C:\Windows」下，
　　然後執行「tsf」資料夾裡的「install.bat」。
　　如果您的 Windows 是 64 位元版，執行「install64.bat」即可。
　　注意：
　　因為使用 Metro 應用程式時不能關閉 UAC（使用者帳戶控制），
　　所以執行上述「install.bat」或「install64.bat」時，
　　請先按右鍵，選「以系統管理員身分執行」，這樣才會安裝成功。
　　安裝成功後，請到「控制台」→「語言」（或「新增語言」）項下，
　　點選「中文(台灣)」旁的「選項」，再依照下列畫面新增「 改良版小小輸入法」：

PS:-
有時仍未叫出yong輸入法，則要以Administrator身份執行 thhui18_Yong\yong.exe
如要一開始就執行yong.exe, 請把yong.exe 的捷徑檔放在Windows的啟動folder內。
---
按右下角的yong輸入法控制panel右手面第四個icon就係toggle for 半形/全形
http://n2.hk/d/attachments/day_140328/20140328_0801ecb2705de86f7241Tj4m13DsRmXJ.jpg

Default is 半形 space，
You can change it to 全形 space

按右下角的yong輸入法控制panel右手面第四個icon就係toggle for 半形/全形
Shift+Space is also the toggle for 半形/全形

加上以下一句在yong.ini的每段中文輸入法裡，
#該輸入法開始時 符號文字皆全形
corner=full
===
其他在趣功能：

手動反查組字字根：
切換到想查的輸入法模式（倉頡、行列30、無蝦米、注音、拼音、大易皆可），
選取並複製想要查的字（必須是單一漢字，而且一定要先按 Ctrl + C 複製起來），
再直接按「Ctrl + ?」，即可反查該字在對應模式下的所有拆碼；
接著，可用滑鼠、方向鍵（加空白鍵）或鍵盤右邊的數字鍵，將反查到的拆碼直接「上屏」。
===
其餘詳細的輸入法設定可以查看 yong.chm file.
